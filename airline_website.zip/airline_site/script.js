// script.js - simple interactivity for the demo site
document.addEventListener('DOMContentLoaded', function(){
  const searchForm = document.getElementById('searchForm');
  if(searchForm){
    searchForm.addEventListener('submit', function(e){
      e.preventDefault();
      const from = document.getElementById('from').value;
      const to = document.getElementById('to').value;
      const date = document.getElementById('date').value;
      const results = document.getElementById('results');
      results.innerHTML = `<div class="card"><h3>Результаты поиска</h3><p>Маршрут: <strong>${from}</strong> → <strong>${to}</strong> | Дата: <strong>${date}</strong></p><p>Ниже — демонстрационная таблица рейсов. В реальном проекте здесь подключается API авиаперевозчика.</p></div>`;
      window.scrollTo({top:results.offsetTop-20, behavior:'smooth'});
    });
  }
});